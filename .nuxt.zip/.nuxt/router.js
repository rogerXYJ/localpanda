import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _60239f5e = () => import('..\\pages\\feedback\\index.vue' /* webpackChunkName: "pages_feedback_index" */).then(m => m.default || m)
const _a5e02192 = () => import('..\\pages\\inquiry\\index.vue' /* webpackChunkName: "pages_inquiry_index" */).then(m => m.default || m)
const _865baca8 = () => import('..\\pages\\error.vue' /* webpackChunkName: "pages_error" */).then(m => m.default || m)
const _49bef9b8 = () => import('..\\pages\\test\\index.vue' /* webpackChunkName: "pages_test_index" */).then(m => m.default || m)
const _f126113c = () => import('..\\pages\\user\\profile.vue' /* webpackChunkName: "pages_user_profile" */).then(m => m.default || m)
const _73e61025 = () => import('..\\pages\\info\\contact-us.vue' /* webpackChunkName: "pages_info_contact-us" */).then(m => m.default || m)
const _5ae3d9be = () => import('..\\pages\\info\\privacy.vue' /* webpackChunkName: "pages_info_privacy" */).then(m => m.default || m)
const _215466d0 = () => import('..\\pages\\info\\about-us.vue' /* webpackChunkName: "pages_info_about-us" */).then(m => m.default || m)
const _480fe15d = () => import('..\\pages\\user\\myBookings.vue' /* webpackChunkName: "pages_user_myBookings" */).then(m => m.default || m)
const _1d7ac4a5 = () => import('..\\pages\\info\\service-terms.vue' /* webpackChunkName: "pages_info_service-terms" */).then(m => m.default || m)
const _e9c00cb2 = () => import('..\\pages\\activity\\payment\\index.vue' /* webpackChunkName: "pages_activity_payment_index" */).then(m => m.default || m)
const _2e1252a8 = () => import('..\\pages\\guide\\payment\\index.vue' /* webpackChunkName: "pages_guide_payment_index" */).then(m => m.default || m)
const _7814fcc9 = () => import('..\\pages\\payment\\success.vue' /* webpackChunkName: "pages_payment_success" */).then(m => m.default || m)
const _6648ade9 = () => import('..\\pages\\guide\\booking.vue' /* webpackChunkName: "pages_guide_booking" */).then(m => m.default || m)
const _7241eee7 = () => import('..\\pages\\payment\\failed.vue' /* webpackChunkName: "pages_payment_failed" */).then(m => m.default || m)
const _13138a7e = () => import('..\\pages\\travel\\china\\index.vue' /* webpackChunkName: "pages_travel_china_index" */).then(m => m.default || m)
const _ce19065e = () => import('..\\pages\\info\\privacy-policy.vue' /* webpackChunkName: "pages_info_privacy-policy" */).then(m => m.default || m)
const _17eb49e8 = () => import('..\\pages\\travel\\customize\\step1.vue' /* webpackChunkName: "pages_travel_customize_step1" */).then(m => m.default || m)
const _2aa37ccf = () => import('..\\pages\\travel\\customize\\done.vue' /* webpackChunkName: "pages_travel_customize_done" */).then(m => m.default || m)
const _17f96169 = () => import('..\\pages\\travel\\customize\\step2.vue' /* webpackChunkName: "pages_travel_customize_step2" */).then(m => m.default || m)
const _180778ea = () => import('..\\pages\\travel\\customize\\step3.vue' /* webpackChunkName: "pages_travel_customize_step3" */).then(m => m.default || m)
const _5f7aba19 = () => import('..\\pages\\guide\\detail\\_id.vue' /* webpackChunkName: "pages_guide_detail__id" */).then(m => m.default || m)
const _668e48a1 = () => import('..\\pages\\activity\\list\\_slug.vue' /* webpackChunkName: "pages_activity_list__slug" */).then(m => m.default || m)
const _5ba311bc = () => import('..\\pages\\guide\\list\\_slug.vue' /* webpackChunkName: "pages_guide_list__slug" */).then(m => m.default || m)
const _15805e48 = () => import('..\\pages\\activity\\booking\\_id.vue' /* webpackChunkName: "pages_activity_booking__id" */).then(m => m.default || m)
const _87b1201c = () => import('..\\pages\\travel\\article\\_articleId.vue' /* webpackChunkName: "pages_travel_article__articleId" */).then(m => m.default || m)
const _76a9d1ca = () => import('..\\pages\\guide\\activity\\_id.vue' /* webpackChunkName: "pages_guide_activity__id" */).then(m => m.default || m)
const _d0a005da = () => import('..\\pages\\activity\\details\\_id.vue' /* webpackChunkName: "pages_activity_details__id" */).then(m => m.default || m)
const _c25d5f72 = () => import('..\\pages\\activity\\recommend\\_loc\\_keywords.vue' /* webpackChunkName: "pages_activity_recommend__loc__keywords" */).then(m => m.default || m)
const _0481ea16 = () => import('..\\pages\\pashStatus\\_slug.vue' /* webpackChunkName: "pages_pashStatus__slug" */).then(m => m.default || m)
const _6f87bf1f = () => import('..\\pages\\travel\\_loc\\_keywords\\_subject.vue' /* webpackChunkName: "pages_travel__loc__keywords__subject" */).then(m => m.default || m)
const _790c0b76 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/feedback",
			component: _60239f5e,
			name: "feedback"
		},
		{
			path: "/inquiry",
			component: _a5e02192,
			name: "inquiry"
		},
		{
			path: "/error",
			component: _865baca8,
			name: "error"
		},
		{
			path: "/test",
			component: _49bef9b8,
			name: "test"
		},
		{
			path: "/user/profile",
			component: _f126113c,
			name: "user-profile"
		},
		{
			path: "/info/contact-us",
			component: _73e61025,
			name: "info-contact-us"
		},
		{
			path: "/info/privacy",
			component: _5ae3d9be,
			name: "info-privacy"
		},
		{
			path: "/info/about-us",
			component: _215466d0,
			name: "info-about-us"
		},
		{
			path: "/user/myBookings",
			component: _480fe15d,
			name: "user-myBookings"
		},
		{
			path: "/info/service-terms",
			component: _1d7ac4a5,
			name: "info-service-terms"
		},
		{
			path: "/activity/payment",
			component: _e9c00cb2,
			name: "activity-payment"
		},
		{
			path: "/guide/payment",
			component: _2e1252a8,
			name: "guide-payment"
		},
		{
			path: "/payment/success",
			component: _7814fcc9,
			name: "payment-success"
		},
		{
			path: "/guide/booking",
			component: _6648ade9,
			name: "guide-booking"
		},
		{
			path: "/payment/failed",
			component: _7241eee7,
			name: "payment-failed"
		},
		{
			path: "/travel/china",
			component: _13138a7e,
			name: "travel-china"
		},
		{
			path: "/info/privacy-policy",
			component: _ce19065e,
			name: "info-privacy-policy"
		},
		{
			path: "/travel/customize/step1",
			component: _17eb49e8,
			name: "travel-customize-step1"
		},
		{
			path: "/travel/customize/done",
			component: _2aa37ccf,
			name: "travel-customize-done"
		},
		{
			path: "/travel/customize/step2",
			component: _17f96169,
			name: "travel-customize-step2"
		},
		{
			path: "/travel/customize/step3",
			component: _180778ea,
			name: "travel-customize-step3"
		},
		{
			path: "/guide/detail/:id?",
			component: _5f7aba19,
			name: "guide-detail-id"
		},
		{
			path: "/activity/list/:slug?",
			component: _668e48a1,
			name: "activity-list-slug"
		},
		{
			path: "/guide/list/:slug?",
			component: _5ba311bc,
			name: "guide-list-slug"
		},
		{
			path: "/activity/booking/:id?",
			component: _15805e48,
			name: "activity-booking-id"
		},
		{
			path: "/travel/article/:articleId?",
			component: _87b1201c,
			name: "travel-article-articleId"
		},
		{
			path: "/guide/activity/:id?",
			component: _76a9d1ca,
			name: "guide-activity-id"
		},
		{
			path: "/activity/details/:id?",
			component: _d0a005da,
			name: "activity-details-id"
		},
		{
			path: "/activity/recommend/:loc?/:keywords?",
			component: _c25d5f72,
			name: "activity-recommend-loc-keywords"
		},
		{
			path: "/pashStatus/:slug?",
			component: _0481ea16,
			name: "pashStatus-slug"
		},
		{
			path: "/travel/:loc?/:keywords?/:subject?",
			component: _6f87bf1f,
			name: "travel-loc-keywords-subject"
		},
		{
			path: "/",
			component: _790c0b76,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
